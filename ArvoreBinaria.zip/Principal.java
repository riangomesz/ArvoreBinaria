package pkgArvoreBinaria;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Arvore a = new Arvore();
		
		a.inserir(150);
		a.inserir(100);
		a.inserir(50);
		a.inserir(120);
		a.inserir(130);
		a.inserir(250);
		a.inserir(220);
		a.inserir(300);
		
		a.emOrdem();
		System.out.println();
		a.preOrdem();
		System.out.println();
		a.posOrdem();
		System.out.println();
		
		TipoNo no = a.pesquisaArvore(220);
		
		if (no != null)
			System.out.println("ACHOU!!");
		else
			System.out.println("NÃO ACHOU!!");

		no = a.pesquisaArvore(10);
		
		if (no != null)
			System.out.println("ACHOU!!");
		else
			System.out.println("NÃO ACHOU!!");
	}
}

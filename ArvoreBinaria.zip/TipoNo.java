package pkgArvoreBinaria;

public class TipoNo {

	int info;
	TipoNo esq, dir;
	
	public TipoNo(int info) {
		this.info = info;
		esq = dir = null;
	}
	
	public String toString() {
		return "->" + info;
	}
}
